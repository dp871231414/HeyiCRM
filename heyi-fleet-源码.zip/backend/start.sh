#!/usr/bin/env sh
# 单容器启动脚本：初始化种子数据 → 启动服务（由后端同源托管前端 SPA）
set -e

# 前端构建产物目录（默认 ./static；不存在时自动退化为纯 API 服务）
export STATIC_DIR="${STATIC_DIR:-./static}"
# 演示库（可用 DATABASE_URL 覆盖为 PostgreSQL）
export DATABASE_URL="${DATABASE_URL:-sqlite:///./app.db}"
# 监听端口（发布沙箱注入 PORT）
PORT="${PORT:-3000}"

echo "[start] python=$(python -V 2>&1) port=${PORT} cwd=$(pwd)"
echo "[start] static_dir=${STATIC_DIR} exists=$([ -d "${STATIC_DIR}" ] && echo yes || echo no)"
echo "[start] database_url=${DATABASE_URL}"

python -c "import fastapi, uvicorn, sqlalchemy; print('[start] deps ok')" || echo "[start] deps check failed"

# 种子数据。
#   默认：幂等补齐（已有数据不动，仅新增缺失项与内置角色权限对齐）
#   SEED_RESET=1：先清空业务表再重新灌入，用于把演示环境恢复到初始状态
# 例如部署时以 `SEED_RESET=1 sh start.sh` 启动一次即可完成重置，之后正常启动即可。
if [ "${SEED_RESET}" = "1" ]; then
  echo "[start] SEED_RESET=1 → 硬重置：删除数据库文件后从零重建"
  # 硬重置：直接删除库文件，规避旧库行级删除在某些沙箱下中断导致库处于
  # 半清空（如用户表被删但重建失败）的异常态；删文件后由 seed 全新建表灌入。
  DB_FILE=$(echo "${DATABASE_URL:-sqlite:///./app.db}" | sed -E 's#^sqlite:///(//)?##')
  if [ -n "${DB_FILE}" ]; then
    rm -f "${DB_FILE}" && echo "[start] 已删除旧库文件 ${DB_FILE}"
  fi
  python -m app.seed --reset || echo "[start] reset skipped or failed (non-fatal)"
else
  python -m app.seed || echo "[start] seed skipped or failed (non-fatal)"
fi

# 一次性数据清理（可选，默认不执行）。
#   用法：PURGE_KEEP="admin,huguohai" sh start.sh
#   执行一次后改回 `sh start.sh` 正常启动即可，不必每次带着它。
# 注意：必须走本脚本，才能复用上面那份 DATABASE_URL；直接在外面跑
#       `python -m app.maintenance` 会拿到代码里的默认值，连到的不是这里在用的库。
if [ -n "${PURGE_KEEP}" ]; then
  PURGE_ARGS="--keep ${PURGE_KEEP}"
  # 清空业务数据时，平台管理员显示名默认统一为「管理员」（可用 PURGE_ADMIN_NAME 覆盖）。
  # 这样无需在部署命令里带中文，也能把预留的管理员账号命名规范到位。
  PURGE_ADMIN_NAME="${PURGE_ADMIN_NAME:-管理员}"
  PURGE_ARGS="${PURGE_ARGS} --admin-name ${PURGE_ADMIN_NAME}"
  echo "[start] PURGE_KEEP=${PURGE_KEEP} → 执行数据清理（保留这些账号，管理员显示名=${PURGE_ADMIN_NAME}）"
  # shellcheck disable=SC2086
  python -m app.maintenance purge ${PURGE_ARGS} || echo "[start] purge failed (non-fatal)"
fi

# 一次性账号改名（可选，默认不执行）。同样必须走本脚本才能用对连接串。
#   用法：RENAME_FROM="旧账号名" RENAME_TO="新账号名" RENAME_PASSWORD="新密码" sh start.sh
#   RENAME_PASSWORD 不传则密码不变。
if [ -n "${RENAME_FROM}" ] && [ -n "${RENAME_TO}" ]; then
  echo "[start] RENAME_FROM=${RENAME_FROM} RENAME_TO=${RENAME_TO} → 执行账号改名"
  if [ -n "${RENAME_PASSWORD}" ]; then
    python -m app.maintenance rename --account "${RENAME_FROM}" --to "${RENAME_TO}" --password "${RENAME_PASSWORD}" \
      || echo "[start] rename failed (non-fatal)"
  else
    python -m app.maintenance rename --account "${RENAME_FROM}" --to "${RENAME_TO}" \
      || echo "[start] rename failed (non-fatal)"
  fi
fi

# 用 python -m 调用，避免 uvicorn 可执行文件不在 PATH 上
exec python -m uvicorn app.main:app --host 0.0.0.0 --port "${PORT}" --log-level info
