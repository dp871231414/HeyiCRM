"""经营驾驶舱路由：分析总结、总览、指标趋势。

**权限口径（重要）**：本模块只按**角色权限**判断能否使用，不做数据范围（可见范围）校验 ——
有 `dashboard.view` 即视为可查看经营分析数据。「全公司与项目公司不是递归汇总关系」
（项目公司只承载运营收入，销售收入来自系统中的其他主体），若按可见范围裁剪，
部门范围账号反而看不到完整的经营口径，容易被误读。

数据范围（scope）**仅用于任务模块**，见 `api/v1/tasks.py`。
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.constants import MARKET_STAGE_VALUES
from app.core.deps import require_perm
from app.db.session import get_db
from app.models import MetricActual, MetricDef, Organization, User
from app.schemas.project import FunnelConfigIn
from app.schemas.task import DeptTaskStat
from app.services.achievement import current_period, group_metric_stats, load_index
from app.services.audit import write_log
from app.services.summary import build_summary

router = APIRouter(prefix="/dashboard", tags=["经营驾驶舱"])


@router.get("/summary")
def summary(period: str = "", org_id: str = "CO", db: Session = Depends(get_db), user: User = Depends(require_perm("dashboard.view"))):
    period = period or current_period()
    if not db.get(Organization, org_id):
        raise HTTPException(status_code=404, detail="组织不存在")
    return build_summary(db, period, org_id)


@router.get("/overview")
def overview(period: str = "", org_id: str = "CO", db: Session = Depends(get_db), user: User = Depends(require_perm("dashboard.view"))):
    period = period or current_period()
    org = db.get(Organization, org_id)
    if not org:
        raise HTTPException(status_code=404, detail="组织不存在")

    from app.api.v1.metrics import build_board

    # 不传可见组织：驾驶舱按全公司口径取数（数据范围不影响本模块）
    board = build_board(db, period, org_id)

    return {
        "period": period,
        "orgId": org_id,
        "orgName": org.name,
        "orgType": org.type,
        "timeProgress": board["timeProgress"],
        "annual": board["annual"],
        "monitor": board["monitor"] if org.type == "company" else [],
        "projectCompare": board["project"]["companies"] if org.type in ("company", "project") else [],
        "projectMetrics": board["project"]["metrics"],
        "counts": board["counts"],
    }


@router.get("/dept-task-stats", response_model=list[DeptTaskStat])
def dept_task_stats(
    period: str = "",
    filter: str = "all",
    db: Session = Depends(get_db),
    user: User = Depends(require_perm("dashboard.view")),
):
    """部门任务完成度（驾驶舱）· 支持按创建时间筛选，独立于总览单独取数。

    之所以不挂在 `/overview` 上：切换筛选只要重算一次 GROUP BY，
    没必要连带重建整套指标看板；而首屏是与 summary / overview 并发取的，不增加往返。

    `filter`：`all` 全部（默认）/ `year` 本年新增 / `month` 当月新增 / `open` 未结束；
    年月均取 `period`（页面顶部统计周期）所在年月，未识别的取值按「全部」处理。
    """
    from app.api.v1.tasks import dept_stats_all, dept_task_filter

    if filter not in ("all", "year", "month", "open"):
        filter = "all"
    return dept_stats_all(db, task_filter=dept_task_filter(period or current_period(), filter))


@router.get("/project-funnel")
def project_funnel(
    dept: str | None = None,
    db: Session = Depends(get_db),
    user: User = Depends(require_perm("dashboard.view")),
):
    """市场项目概览：三漏斗（项目数 / 牵引车需求 / 挂车需求）+ 加权销量预测。

    只按角色权限开放，不做数据范围裁剪（与驾驶舱其他模块同一口径）。
    漏斗为各阶段当前数量口径（不向上累计），预测按项目各自阶段的转化概率加权。

    `dept`：筛选标签对应的二级部门 ID（市场部的直接子部门）。不传或为空时展示
    「全部」——市场部及其下属部门全体负责人名下的项目；返回值里的 `deptOptions`
    即市场部当前全部二级部门，供前端渲染筛选标签，随组织变化同步更新。
    """
    from app.services.funnel import build_funnel

    return build_funnel(db, dept_id=dept or None)


@router.get("/demand-analysis")
def demand_analysis(
    dept: str | None = None,
    db: Session = Depends(get_db),
    user: User = Depends(require_perm("dashboard.view")),
):
    """车辆需求分析：车头按(车型+电池容量)组合、挂车按车型分行统计实际录入的需求明细。

    只按角色权限开放，不做数据范围裁剪（与驾驶舱其余模块同一口径）。
    `dept`：二级部门 ID 时只统计该部门负责人的项目；为空（全部）统计市场部子树全部负责人。
    返回结构含 stages（阶段与转化率，供前端渲染筛选标签后缀）、tractor/trailer（all + byStage 两套聚合）。
    """
    from app.services.funnel import build_demand_analysis

    return build_demand_analysis(db, dept_id=dept or None)


@router.get("/funnel-config")
def funnel_config(db: Session = Depends(get_db), user: User = Depends(require_perm("dashboard.view"))):
    """各阶段转化概率（默认值 = 阶段百分比）。"""
    from app.services.funnel import load_probs

    probs = load_probs(db)
    return {"probs": [{"stage": s, "prob": p} for s, p in sorted(probs.items())]}


@router.put("/funnel-config")
def save_funnel_config(
    payload: FunnelConfigIn,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(require_perm("dashboard.config")),
):
    """整份保存六个阶段的转化概率（全系统共用一份，立即影响销量预测）。"""
    from app.services.funnel import load_probs, save_probs

    incoming = {item.stage: item.prob for item in payload.probs}
    expected = set(MARKET_STAGE_VALUES)
    if set(incoming) != expected:
        raise HTTPException(status_code=422, detail="需完整提供六个阶段的转化概率")
    probs = save_probs(db, incoming)
    write_log(db, user, "update", "funnel_config", "global", {"probs": probs}, request)
    db.commit()
    return {"probs": [{"stage": s, "prob": p} for s, p in sorted(load_probs(db).items())]}


@router.get("/metrics/{metric_id}/trend")
def trend(metric_id: str, org_id: str = "CO", db: Session = Depends(get_db), user: User = Depends(require_perm("dashboard.view"))):
    d = db.get(MetricDef, metric_id)
    if not d:
        raise HTTPException(status_code=404, detail="指标不存在")
    rows = db.execute(
        select(MetricActual.period, MetricActual.value)
        .where(MetricActual.metric_id == metric_id, MetricActual.org_id == org_id)
        .order_by(MetricActual.period)
    ).all()
    return {
        "metricId": metric_id,
        "name": d.name,
        "unit": d.unit,
        "direction": d.direction,
        "points": [{"period": str(p), "value": float(v)} for p, v in rows],
    }


@router.get("/metrics/trends")
def trends(
    ids: str = "",
    org_id: str = "CO",
    db: Session = Depends(get_db),
    user: User = Depends(require_perm("dashboard.view")),
):
    """批量取多个指标的趋势（一次请求代替 N 次）。

    指标维护页原先为每个监控指标各发一个 trend 请求。在单次往返约 300ms 的环境下，
    10 个并发会互相争抢（实测尾请求 TTFB 被拖到 2.4 秒），而表格又必须等全部返回。
    合并成一次请求后只剩一个往返，且只查一次库。
    """
    metric_ids = [i.strip() for i in ids.split(",") if i.strip()]
    if not metric_ids:
        return {"series": []}

    defs = {d.id: d for d in db.scalars(select(MetricDef).where(MetricDef.id.in_(metric_ids))).all()}
    rows = db.execute(
        select(MetricActual.metric_id, MetricActual.period, MetricActual.value)
        .where(MetricActual.metric_id.in_(metric_ids), MetricActual.org_id == org_id)
        .order_by(MetricActual.metric_id, MetricActual.period)
    ).all()
    grouped: dict[str, list[dict]] = {}
    for mid, period, value in rows:
        grouped.setdefault(mid, []).append({"period": str(period), "value": float(value)})

    series = []
    for mid in metric_ids:  # 保持调用方给定的顺序
        d = defs.get(mid)
        if not d:
            continue
        series.append(
            {
                "metricId": mid,
                "name": d.name,
                "unit": d.unit,
                "direction": d.direction,
                "points": grouped.get(mid, []),
            }
        )
    return {"series": series}
