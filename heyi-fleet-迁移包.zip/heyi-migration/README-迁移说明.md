# 和毅车队经营看板 · 迁移包说明

本压缩包用于将该项目**整体迁移到任意 AI Agent / 研发工具**进行后续理解与迭代。包内结构：

```
heyi-fleet-dashboard/        # 项目源码（已排除 node_modules/.git/*.db/构建产物）
├─ backend/                  # FastAPI 后端（app/、tests/、tools/、start.sh、requirements.txt）
├─ frontend/                 # Vue3 + TS 前端（src/，含构建产物 dist 已排除）
├─ docs/                     # 七类文档源文件（与仓库 docs/ 一致）
└─ README / pyproject 等
文档/                        # 全部交付文档（产品需求/技术/测试/使用说明HTML/设计/Skill/项目开发说明）
项目记忆/                    # .workbuddy/memory 迭代日志与长期约定（接手上下文）
README-迁移说明.md           # 本文件
```

## 一、本地运行
1. 后端：`cd backend && python -m venv .venv && pip install -r requirements.txt`
2. 初始化：`python -m app.seed`（默认幂等；`SEED_RESET=1` 硬重置）
3. 启动：`bash start.sh`（监听 `$PORT`，默认 3000；SQLite 文件 `app.db`）
4. 前端：`cd frontend && npm install && npm run build && cp -R dist/. ../backend/static/`
   > 关键：前端构建产物必须 `cp` 进 `backend/static/` 再启动后端，否则线上前端为旧构建。

## 二、自动更新文档（核心机制）
文档内容存于数据库 `system_doc` 表，由「系统配置 → 使用说明」文档中心读取渲染。
- 源文件在 `docs/`：`产品需求文档.md` / `技术文档.md` / `测试文档.md` / `使用说明.html` / `设计文档.md` / `skill文档.md` / `项目开发说明.md`。
- 每次迭代：更新 `docs/` → 复制到 `backend/bundled_docs/` → 调用 `POST /system/docs/sync` 写入数据库。
- 界面内管理员可点「同步最新」或「编辑」直接维护。

## 三、接手必读顺序
1. `项目记忆/` → 了解迭代史与红线约定（线下数据不自动同步生产等）。
2. `文档/项目开发说明.md` → 各 Round 决策与经验。
3. `文档/技术文档.md` → 架构、数据模型、接口清单、部署三步。
4. `文档/skill文档.md` → 本项目的 Agent 协作与迭代标准动作。

## 四、红线（勿违反）
- 线下数据库业务数据除非显式提出，不自动向生产同步；仅发布代码与 seed 配置默认值。
- 已存在的数据字典配置只允许启用/停用，不允许删除。
- 线上验证使用临时数据须测试后清除，不污染生产。

## 五、测试
- 后端：`cd backend && pytest -q`（当前 169 passed，含 `test_system_doc.py`）。
- 前端：`cd frontend && npm run build`（含类型检查）。
- 线上验证脚本：`backend/tools/verify_live_roundNN.py`（Cookie 鉴权，验证后清理）。
