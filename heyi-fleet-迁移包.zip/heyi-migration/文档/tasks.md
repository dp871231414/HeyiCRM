# 合一重卡生态经营看板 · 任务清单（tasks）

> 排序原则：基础设施 → 核心功能 → 界面 → 部署与验收
> 每个任务完成后对照「完成标准」自检、验收并单独提交（`feat: complete T<n> <任务名>`）。

## T1 工程骨架与配置
- 优先级：P0
- 前置依赖：无
- 涉及文件/模块：`backend/app/{config,main}.py`、`backend/app/db/{base,session}.py`、`backend/requirements.txt`、`frontend/{package.json,vite.config.ts,tailwind.config.js,tsconfig.json,index.html}`、`deploy/.env.example`
- 具体工作内容：搭建后端 FastAPI 目录骨架与配置模块（环境变量外置）；搭建前端 Vite + TS + Tailwind 工程骨架；编写依赖清单
- 完成标准：后端 `python -c "import app.main"` 通过；前端 `npm install && npm run build` 通过
- 验证方式：`uvicorn app.main:app --help` 与 `npm run build`
- 是否可并行：否

## T2 数据模型与迁移
- 优先级：P0
- 前置依赖：T1
- 涉及文件/模块：`backend/app/models/*`、`backend/app/db/base.py`、`backend/alembic/*`
- 具体工作内容：实现 organization / metric_def / metric_target / metric_actual / task / user / role / operation_log 八张表的 ORM；配置 Alembic 并生成初始迁移
- 完成标准：`alembic upgrade head` 建表成功；`alembic downgrade base` 可回滚
- 验证方式：迁移命令 + 表结构核对
- 是否可并行：否

## T3 种子数据
- 优先级：P0
- 前置依赖：T2
- 涉及文件/模块：`backend/app/seed.py`
- 具体工作内容：写入全公司 + 11 个二级部门 + 3 家项目公司、24 项指标定义、年度/项目公司目标、演示账号（管理员/部门负责人/成员/项目公司负责人）、3 个内置角色
- 完成标准：执行脚本后各表有数据；`seed --reset` 可重复执行
- 验证方式：查询各表行数
- 是否可并行：是（与 T4 无文件冲突）

## T4 鉴权与权限依赖
- 优先级：P0
- 前置依赖：T2, T3
- 涉及文件/模块：`backend/app/core/{security,deps}.py`、`backend/app/api/v1/auth.py`
- 具体工作内容：bcrypt 密码哈希；JWT 签发/校验；`get_current_user`、`require_perm`、`require_any_perm` 依赖；登录/登出/me 接口；登录写 operation_log（含 IP）
- 完成标准：正确凭据返回令牌；错误凭据 401；无权限访问受保护接口 403
- 验证方式：pytest + curl
- 是否可并行：否

## T5 组织与项目公司 API
- 优先级：P0
- 前置依赖：T4
- 涉及文件/模块：`backend/app/api/v1/{orgs,projects}.py`、`backend/app/schemas/org.py`
- 具体工作内容：组织树/扁平列表、部门增改删（含删除约束）、影响面；项目公司列表/新增/编辑/删除（连带清理与账号停用）
- 完成标准：重名 409；有账号的部门删除 409；删除项目公司后其目标/完成值/任务被清理
- 验证方式：pytest
- 是否可并行：是

## T6 角色与账号 API
- 优先级：P0
- 前置依赖：T4
- 涉及文件/模块：`backend/app/api/v1/{roles,users}.py`、`backend/app/schemas/{role,user}.py`
- 具体工作内容：权限清单接口；角色增删改（内置/占用约束）；账号增删改查、启停用、可见范围覆盖
- 完成标准：内置角色删除 409；角色下有账号删除 409；账号 scope 留空则跟随角色
- 验证方式：pytest
- 是否可并行：是（与 T5 无文件冲突）

## T7 指标计算与范围服务
- 优先级：P0
- 前置依赖：T2
- 涉及文件/模块：`backend/app/services/{achievement,scope}.py`
- 具体工作内容：达成率（正向/逆向/零目标）、红黄绿灯、回款率与回款灯、时间进度、加权；可见组织集合、可见任务过滤
- 完成标准：单元测试覆盖三类指标判定与四类范围
- 验证方式：pytest
- 是否可并行：是

## T8 指标 API 与维护看板数据
- 优先级：P0
- 前置依赖：T5, T7
- 涉及文件/模块：`backend/app/api/v1/metrics.py`、`backend/app/schemas/metric.py`
- 具体工作内容：指标定义、周期、维护看板一次性数据（三模块）、目标/完成值 upsert（年度目标换算年份周期）、权限与范围校验
- 完成标准：维护看板返回三模块且口径与驾驶舱一致；越权 org_id 返回 403
- 验证方式：pytest + curl
- 是否可并行：否

## T9 任务 API 与部门聚合
- 优先级：P0
- 前置依赖：T5, T7
- 涉及文件/模块：`backend/app/api/v1/tasks.py`、`backend/app/schemas/task.py`
- 具体工作内容：任务增删改查（服务端范围过滤）、部门任务完成度聚合（SQL GROUP BY）、筛选与分页
- 完成标准：成员仅见本人相关任务；部门聚合与逐条计算一致
- 验证方式：pytest
- 是否可并行：否

## T10 分析总结服务与驾驶舱 API
- 优先级：P0
- 前置依赖：T7, T8, T9
- 涉及文件/模块：`backend/app/services/summary.py`、`backend/app/api/v1/dashboard.py`
- 具体工作内容：规则生成分析总结（结论/亮点/风险/建议）；驾驶舱总览（核心指标/项目公司对比/监控/部门任务）；指标趋势
- 完成标准：无 AI 依赖；空数据返回空态不报错；汇总在 SQL 层完成
- 验证方式：pytest
- 是否可并行：否

## T11 Excel 导入与导出
- 优先级：P1
- 前置依赖：T8, T9
- 涉及文件/模块：`backend/app/services/importer.py`、`backend/app/api/v1/{tasks,metrics}.py`
- 具体工作内容：任务模板（11 列）与指标模板生成下载；逐行校验（任务 8 类）；原子导入；任务导出
- 完成标准：含错误行时返回错误明细且不写入脏数据；合法行正确入库
- 验证方式：pytest + 真实上传演示
- 是否可并行：是

## T12 前端骨架与外壳
- 优先级：P0
- 前置依赖：T1
- 涉及文件/模块：`frontend/src/{main.ts,App.vue}`、`router/`、`stores/`、`api/`、`layouts/`、`styles/`
- 具体工作内容：路由与权限守卫、Pinia 状态、Axios 封装（令牌与 401/403 拦截）、侧边栏+顶栏外壳、设计令牌与 Tailwind 主题
- 完成标准：登录后进入外壳；未登录访问业务路由跳登录；无权限菜单不渲染
- 验证方式：`npm run build` + 浏览器手工
- 是否可并行：否

## T13 登录页
- 优先级：P0
- 前置依赖：T4, T12
- 涉及文件/模块：`frontend/src/views/LoginView.vue`
- 具体工作内容：品牌视觉区（含科技感装饰）、登录表单、错误提示；未登录不请求任何业务数据
- 完成标准：正确凭据进入系统；错误提示不泄露账号存在性
- 验证方式：浏览器手工 + 组件测试
- 是否可并行：是

## T14 经营驾驶舱页
- 优先级：P0
- 前置依赖：T10, T12
- 涉及文件/模块：`frontend/src/views/DashboardView.vue`、相关组件
- 具体工作内容：分析总结区、核心指标卡（含回款与时间进度）、项目公司对比、监控区、部门任务完成度、风险清单（置文末）
- 完成标准：各区块渲染无 NaN/undefined；空态正确；点「去维护」定位到指标页
- 验证方式：浏览器手工 + 截图
- 是否可并行：是

## T15 任务管理页
- 优先级：P0
- 前置依赖：T9, T11, T12
- 涉及文件/模块：`frontend/src/views/TasksView.vue`、组件
- 具体工作内容：任务表（冻结列/横滑）、搜索筛选、增删改、导入导出、弹窗表单
- 完成标准：完成进度与状态由服务端计算且展示正确；按钮按权限显隐
- 验证方式：浏览器手工
- 是否可并行：是

## T16 指标维护页
- 优先级：P0
- 前置依赖：T8, T11, T12
- 涉及文件/模块：`frontend/src/views/MetricsView.vue`、组件
- 具体工作内容：三模块布局、行内录入与保存、项目公司列表化增删、导入、与驾驶舱互跳定位
- 完成标准：保存后驾驶舱同步；未录入显示「—」；项目公司增删生效
- 验证方式：浏览器手工
- 是否可并行：是

## T17 账号管理页（账号/组织/角色）
- 优先级：P0
- 前置依赖：T5, T6, T12
- 涉及文件/模块：`frontend/src/views/AccountsView.vue`、组件
- 具体工作内容：账号页签、组织结构页签（部门 CRUD）、角色权限页签（勾选树 + 可见范围）
- 完成标准：删除约束正确提示；菜单权限取消联动按钮权限；组织页无项目公司入口
- 验证方式：浏览器手工
- 是否可并行：是

## T18 部署编排与文档
- 优先级：P0
- 前置依赖：T12 ~ T17
- 涉及文件/模块：`deploy/docker-compose.yml`、`deploy/nginx.conf`、`backend/Dockerfile`、`frontend/Dockerfile`、`README.md`
- 具体工作内容：一键启动数据库/后端/前端/Nginx；环境变量外置；部署手册
- 完成标准：`docker compose up` 后浏览器可访问并登录
- 验证方式：本地 compose 启动核对
- 是否可并行：否

## T19 端到端验收与回归
- 优先级：P0
- 前置依赖：T1 ~ T18
- 涉及文件/模块：`backend/tests/`、验收记录
- 具体工作内容：逐条执行 proposal §11 验收标准；修复发现的问题
- 完成标准：AC-01 ~ AC-39 全部通过
- 验证方式：pytest + 浏览器手工逐条核对
- 是否可并行：否

## T20 第二批变更（2026-10-12）

对应 proposal §12 / design §13。

| 项 | 内容 | 涉及 | 状态 |
|---|---|---|---|
| T20-1 | 统计周期移到驾驶舱/指标维护页内，月份组件（2026-09 ~ 2099-12） | `constants/period.ts`、`MonthPicker.vue`、`stores/view.ts`、`AppLayout.vue`、两个页面 | ✅ |
| T20-2 | 完成值口径明确为「累计完成值」 | `MetricsView.vue`、`DashboardView.vue`、`achievement.py`、`constants.py`、`seed.py` | ✅ |
| T20-3 | 任务列表增加创建人（+ 创建/更新时间已有，本轮暴露） | `achievement.task_to_dict`、`schemas/task.py`、`tasks.py._enrich`、`TasksView.vue` | ✅ |
| T20-4 | 任务分组视图（按部门，带小标题） | `TasksView.vue`（`rows` computed 复用同一张表） | ✅ |
| T20-5 | 导入模板字段与列表一致（命名统一 + 补「数量单位」） | `importer.TASK_COLUMNS`、`tasks.py` 导入列、`validate_task_rows`、`import_tasks` | ✅ |
| T20-6 | 导入/导出模板美化（说明栏 + 表头背景 + 蓝色清新） | `importer` 样式层、`export_tasks` | ✅ |
| T20-7 | 指标维护下线模板下载与批量导入入口 | `MetricsView.vue` | ✅ |
| T20-8 | 文档与用例同步、输出测试报告 | `proposal.md`、`design.md`、`test-report.md`、`tests/test_changes.py`、`tests/test_api.py` | ✅ |

## T21 第三批变更（2026-10-12）

对应 proposal §12.3 / design §13.4。

| 项 | 内容 | 涉及 | 状态 |
|---|---|---|---|
| T21-1 | 月份选择组件重做（面板式：触发器 + 12 月网格 + 年份分页跳转 + 越界禁用 + 外部点击/Esc 关闭） | `components/MonthPicker.vue`、`styles/main.css` | ✅ |
| T21-2 | 项目公司增 / 改 / 删改为独立权限点，入口不再依赖当前视角 | `constants.py`、`seed.py`、`api/v1/projects.py`、`views/MetricsView.vue` | ✅ |
| T21-3 | 删除项目公司时清理悬空引用（子组织上移、账号迁移并停用） | `api/v1/projects.py` | ✅ |
| T21-4 | 回归用例与验收脚本（新增 5 条后端用例 + `tools/verify-round3.mjs`） | `tests/test_changes.py`、`tools/` | ✅ |
| T21-5 | 文档同步与测试报告 | `proposal.md`、`design.md`、`tasks.md`、`test-report.md` | ✅ |

## T22 第四批变更（2026-10-12）

对应 proposal §12.5 / design §13.5。

| 项 | 内容 | 涉及 | 状态 |
|---|---|---|---|
| T22-1 | 统计周期面板增加「本月」快捷项 | `components/MonthPicker.vue` | ✅ |
| T22-2 | 任务列表分页（平铺 50 / 分组每组 20）+ 分页器组件 | `components/PaginationBar.vue`、`views/TasksView.vue` | ✅ |
| T22-3 | 冻结列缝隙改纯色；分组标题横向滚动时固定 | `styles/main.css`、`views/TasksView.vue` | ✅ |
| T22-4 | 后端分页与状态过滤下推 SQL + size 上限 | `api/v1/tasks.py` | ✅ |
| T22-5 | 加载性能：gzip 压缩 + 静态资源强缓存 + index.html 不缓存 | `app/main.py` | ✅ |
| T22-6 | 用例、验收脚本、文档与上线 | `tests/test_changes.py`、`tools/verify-round4.mjs`、`docs/` | ✅ |

## T23 第五批变更（2026-10-12）

对应 proposal §12.7 / design §13.8。

| 项 | 内容 | 涉及 | 状态 |
|---|---|---|---|
| T23-1 | 权限目录支持子分组，指标维护按三块组织编辑权限 | `constants.py`、`types/index.ts`、`AccountsView.vue` | ✅ |
| T23-2 | 去掉 metric.edit 的全局前置，三块权限独立（含写入接口按块校验） | `api/v1/metrics.py` | ✅ |
| T23-3 | 批量趋势接口 + 前端不再阻塞渲染 | `api/v1/dashboard.py`、`api/index.ts`、`MetricsView.vue` | ✅ |
| T23-4 | 用例（按块权限独立性、批量与单个一致性）与验收脚本 | `tests/test_changes.py`、`tools/verify-round5.mjs`、`tools/diag-metrics.mjs` | ✅ |
| T23-5 | 文档与上线 | `docs/` | ✅ |

## T24 第六批变更（2026-10-12）

对应 proposal §12.9 / design §13.9。

| 项 | 内容 | 涉及 | 状态 |
|---|---|---|---|
| T24-1 | 创建 / 更新组织接口返回真实的深度与统计数（原先为硬编码占位值） | `api/v1/orgs.py` | ✅ |
| T24-2 | 保存后就地更新列表，不整块进入加载态；新建 / 删除用静默重载 | `views/AccountsView.vue` | ✅ |
| T24-3 | 「全公司」允许编辑名称与负责人（删除仍受限） | `api/v1/orgs.py`、`AccountsView.vue` | ✅ |
| T24-4 | 用例与验收脚本 | `tests/test_changes.py`、`tools/verify-round6.mjs` | ✅ |

## T25 第七批变更（2026-10-12）

对应 proposal §12.11 / design §13.10。

| 项 | 内容 | 涉及 | 状态 |
|---|---|---|---|
| T25-1 | 移除顶栏「组织视角」下拉 | `layouts/AppLayout.vue` | ✅ |
| T25-2 | `orgId` 语义收敛为「当前数据范围」，按可见范围直接确定 | `stores/view.ts`、`AppLayout.vue` | ✅ |
| T25-3 | 页面文案调整（不再出现"切换组织视角"的指引） | `MetricsView.vue`、`DashboardView.vue` | ✅ |
| T25-4 | 验收脚本同步（去掉视角相关断言，补「无视角下拉」断言） | `tools/*.mjs` | ✅ |

## T26 第八批变更（2026-10-12）

对应 proposal §12.13 / design §13.11。

| 项 | 内容 | 涉及 | 状态 |
|---|---|---|---|
| T26-1 | 驾驶舱去掉数据范围校验与项目公司裁剪（含任务统计改全量口径） | `api/v1/dashboard.py`、`services/summary.py`、`api/v1/tasks.py` | ✅ |
| T26-2 | 指标维护去掉范围校验；项目公司可维护范围改为「按权限」 | `api/v1/metrics.py`、`api/v1/projects.py` | ✅ |
| T26-3 | 前端取数口径统一为全公司，移除「本人范围」空态 | `layouts/AppLayout.vue`、`stores/view.ts`、`views/DashboardView.vue`、`views/MetricsView.vue` | ✅ |
| T26-4 | `services/scope.py` 收敛语义（仅任务模块）并清理死代码 | `services/scope.py`、`core/deps.py` 注释 | ✅ |
| T26-5 | 用例调整与新增、验收脚本、文档同步 | `tests/`、`tools/verify-round7.mjs`、`docs/` | ✅ |

## T27 第九批变更（2026-10-13）

对应 proposal §12.15 / design §13.12。

| 项 | 内容 | 涉及 | 状态 |
|---|---|---|---|
| T27-1 | 设计代币重建：Electric Blue 色阶、accent-tinted 阴影、圆角、等宽字体栈、动效关键帧 | `tailwind.config.js` | ✅ |
| T27-2 | 基础组件层重做（card/btn/input/th/td/chip）+ 新增 section-title / section-label / gradient-text / stat-value / dot-grid | `styles/main.css` | ✅ |
| T27-3 | 布局与登录页改造（品牌标识、侧边栏选中态、顶栏、登录视觉区、区块标识） | `layouts/AppLayout.vue`、`views/LoginView.vue` | ✅ |
| T27-4 | 驾驶舱深色反转总结卡（语义色深色适配 + 纹理 + 光晕） | `views/DashboardView.vue` | ✅ |
| T27-5 | 页面与组件配色统一（标题/数值样式收口、Sparkline 硬编码色、MonthPicker 焦点环、分段控件） | `views/*.vue`、`components/*.vue` | ✅ |
| T27-6 | 清理「一级任务/二级任务」旧叫法（前端/后端/文档） | 多文件 | ✅ |
| T27-7 | 视觉验收脚本与文档同步 | `tools/verify-round8.mjs`、`docs/` | ✅ |

## T28 第十批变更（2026-10-13）

对应 proposal §12.17 / design §13.13。

| 项 | 内容 | 涉及 | 状态 |
|---|---|---|---|
| T28-1 | 分析总结卡改浅色（左侧语义色条 + 浅色徽章），移除深色底/点阵/光晕 | `views/DashboardView.vue` | ✅ |
| T28-2 | 新增表现分级 `perfTone`，三处（徽章/文字/进度条）共用一套取色 | `views/DashboardView.vue` | ✅ |
| T28-3 | 「vs 时间进度」改为中性色；回款率仅未达目标时着色 | `views/DashboardView.vue` | ✅ |
| T28-4 | 验收脚本与文档同步 | `tools/verify-round9.mjs`、`docs/` | ✅ |

## T29 第十一批变更（2026-10-13）

对应 proposal §12.19 / design §13.14。

| 项 | 内容 | 涉及 | 状态 |
|---|---|---|---|
| T29-1 | 新增 `progress_tone`，作为全系统唯一状态判定 | `services/achievement.py` | ✅ |
| T29-2 | 指标行新增 `tone` 字段；汇总统计按 tone；项目公司完成率带 `completionTone` | `api/v1/metrics.py`、`services/achievement.py` | ✅ |
| T29-3 | 分析总结改用 tone 分组与文案；整体结论字段 `tone` → `verdict` | `services/summary.py` | ✅ |
| T29-4 | 前端新增共用样式模块 `utils/tone.ts`，两页接入 | `utils/tone.ts`、`views/DashboardView.vue`、`views/MetricsView.vue`、`types/index.ts` | ✅ |
| T29-5 | 用例（分档、两页一致性、计数同源、文案）与验收脚本 | `tests/test_changes.py`、`tools/verify-round10.mjs` | ✅ |

## T30 第十二批变更（2026-10-13）

对应 proposal §12.21 / design §13.15。

| 项 | 内容 | 涉及 | 状态 |
|---|---|---|---|
| T30-1 | 整体结论改用 `progress_tone`（阈值 1 / 0.7），去掉绝对值门槛与滞后项数条件 | `services/summary.py` | ✅ |
| T30-2 | 结论文案改为与时间进度挂钩的表述；前端徽章文案同步 | `services/summary.py`、`views/DashboardView.vue` | ✅ |
| T30-3 | 用例与验收脚本（含三档实测）；验收脚本改用位置锚点定位总结卡 | `tests/test_changes.py`、`tools/verify-round9.mjs`、`tools/verify-round10.mjs` | ✅ |
