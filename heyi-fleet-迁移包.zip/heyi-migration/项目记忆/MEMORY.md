# 项目长期记忆（车队经营看板 heyi-fleet-dashboard）

## 发布与线上验证约定
- **发布约束**：发布线上时不允许修改生产数据库；验证测试时新造数据测试后删除（已遵守）。
- **【红线·用户明确】线下数据不自动同步生产**：本地数据库的业务数据（任务/项目/指标/账号等）**除非用户在本轮明确提出**，否则**绝不允许自动向生产同步**。可发布的是「代码与 seed 中的配置默认值」（如数据字典预设），但绝不把本地库里已有的业务记录推上去。seed 演示数据已用 `SEED_DEMO` 门控（线上默认不灌），沙箱重建后只保留结构数据 + admin，天然满足此红线。
- **部署**：`workbuddy_sites_deploy`，directory=`backend/`，language=python，startCmd=`bash start.sh`（监听 `$PORT`、0.0.0.0，启动幂等 seed）。线上地址 `https://heyi-fleet-dashboard.app.workbuddy.host/`，沙箱重建后库回到演示初态。
- **默认账号**：`admin` / `123456`（SEED_PASSWORD）。
- **线上验证鉴权坑**：部署反代会改写 `Authorization` 头，API 调用须走登录下发的 HttpOnly Cookie（`access_token`），Bearer 头会失效。参考 `backend/tools/verify_live.py`。

## 代码架构要点
- 市场项目真实模块是 `backend/app/api/v1/market.py`（前缀 `/market-projects`），**不是** `api/v1/projects.py`（那是项目公司 Organization，无关）。
- 进展时间轴模式：任务 `TaskProgress`、市场项目 `ProjectProgress`，均冗余最新一条到主表 `progress`/`note` 字段供列表列与导出。
- **FastAPI 路由顺序坑**：静态路由（如 `GET /export`、`GET /import/template`）必须声明在动态路由（`GET /{project_id}`）之前，否则被后者截获返回 404。

## git / 提交
- `*.db` 与 `backend/static/`（前端构建产物）均被 .gitignore 忽略，部署时由 `frontend/dist` 拷入，不进源码仓库。
- 提交信息用 `roundNN: ...` 前缀，保持可追溯。

## 已知坑（供后续参考）
- **Pydantic v2 field_validator 不校验「被省略且有默认值」的字段**：若字段 `x: str = ""` 且用 `field_validator("x")` 判空，客户端**不发该字段**时只套默认值、validator 不触发，空值会被接受。强制必填必须去掉默认（或改用 `model_validator(mode="after")` 对默认值也生效）。round28 项目描述必填即踩此坑，靠线上验证暴露，后改为必填字段 + validator 判空白修复。
- **本地 152 passed ≠ 线上无回归**：本地测试若没覆盖「省略字段/缺 key」路径，部署后才会暴露。发布后务必跑针对新行为的线上专项验证（参考 `backend/tools/verify_live_round28.py` 写法：登录拿 Cookie、按 scope 过滤、边界长度、联合唯一、删除后不可见）。
